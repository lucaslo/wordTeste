<?php

	class AvadaRedux_Customizer_Control_checkbox extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-checkbox";
	}
	class AvadaRedux_Customizer_Control_color_rgba extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-color_rgba";
	}
	class AvadaRedux_Customizer_Control_color extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-color";
	}
	//class AvadaRedux_Customizer_Control_raw extends AvadaRedux_Customizer_Control {
	//    public $type = "avadaredux-raw";
	//}
	class AvadaRedux_Customizer_Control_media extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-media";
	}
	class AvadaRedux_Customizer_Control_spinner extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-spinner";
	}
	class AvadaRedux_Customizer_Control_palette extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-palette";
	}
	class AvadaRedux_Customizer_Control_button_set extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-button_set";
	}
	class AvadaRedux_Customizer_Control_image_select extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-image_select";
	}
	class AvadaRedux_Customizer_Control_radio extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-radio";
	}
	class AvadaRedux_Customizer_Control_select extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-select";
	}
	class AvadaRedux_Customizer_Control_gallery extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-gallery";
	}
	class AvadaRedux_Customizer_Control_slider extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-slider";
	}
	class AvadaRedux_Customizer_Control_sortable extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-sortable";
	}
	class AvadaRedux_Customizer_Control_switch extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-switch";
	}
	class AvadaRedux_Customizer_Control_text extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-text";
	}
	class AvadaRedux_Customizer_Control_textarea extends AvadaRedux_Customizer_Control {
		public $type = "avadaredux-textarea";
	}
